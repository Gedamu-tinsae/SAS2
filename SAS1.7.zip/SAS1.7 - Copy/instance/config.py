# instance/config.py
class Config:
    SECRET_KEY = 'your_secret_key'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = 'app/static/uploads'  # Directory where uploaded files will be saved
    MAX_CONTENT_LENGTH = 32 * 1024 * 1024  # Max file size (16MB)

    # Add these configuration options // school premises
    SCHOOL_LATITUDE = 22.552786
    SCHOOL_LONGITUDE = 72.924109
    ALLOWED_RADIUS = 200
