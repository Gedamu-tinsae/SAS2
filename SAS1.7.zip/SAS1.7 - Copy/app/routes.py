from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app, jsonify,abort
from flask_login import login_user, current_user, logout_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from .forms import RegistrationForm, LoginForm, UploadForm
from .models import User, AttendanceRecord, ScheduleEntry,Student, Teacher, Class, AttendanceStatus, FeatureToggle
from . import db
from datetime import datetime
import os
import cv2
import numpy as np
import base64
from werkzeug.utils import secure_filename
from app import db
from .utils import calculate_attendance_percentage, get_attendance_details, is_within_school
from app.facial_recognition import train_model as train_model_function, recognize_face
from app.facial_recognition import train_model, get_model_directory
import io
from PIL import Image
from flask import abort
import traceback
import logging
from sqlalchemy import and_
from sqlalchemy.orm import aliased


# Define the main blueprint
main = Blueprint('main', __name__)


@main.route('/')
def index():
    return redirect(url_for('main.login'))


@main.route('/student_options')
@login_required
def student_options():
    student = Student.query.filter_by(user_id=current_user.id).first()

    train_model_toggle = FeatureToggle.query.filter_by(feature_name='train_model').first()
    train_model_enabled = train_model_toggle.is_enabled if train_model_toggle else False

    if student:
        attendance_records = AttendanceRecord.query.filter_by(student_id=student.id).all()
        schedule_entries = ScheduleEntry.query.filter_by(student_id=student.id).all()

        can_take_attendance = any(
            AttendanceStatus.query.filter_by(
                day=entry.day_of_week, 
                period=f"{entry.time_start}-{entry.time_end}"
            ).first() is not None and
            AttendanceStatus.query.filter_by(
                day=entry.day_of_week, 
                period=f"{entry.time_start}-{entry.time_end}"
            ).first().status
            for entry in schedule_entries
        )
    else:
        student = None
        attendance_records = []
        can_take_attendance = False

    return render_template(
        'student_options.html',
        student=student,
        attendance_records=attendance_records,
        can_take_attendance=can_take_attendance,
        train_model_enabled=train_model_enabled
    )



@main.route('/admin_dashboard', methods=['GET', 'POST'])
def admin_dashboard():
    if not current_user.is_authenticated or not current_user.is_admin:
        return redirect(url_for('main.login'))

    train_model_toggle = FeatureToggle.query.filter_by(feature_name='train_model').first()

    if request.method == 'POST':
        if train_model_toggle:
            train_model_toggle.is_enabled = not train_model_toggle.is_enabled
        else:
            train_model_toggle = FeatureToggle(feature_name='train_model', is_enabled=True)
            db.session.add(train_model_toggle)
        
        db.session.commit()
        flash('Train Model feature toggle updated!', 'success')
        return redirect(url_for('main.admin_dashboard'))

    return render_template('admin_dashboard.html', train_model_toggle=train_model_toggle)



@main.route('/teacher-options', methods=['GET', 'POST'])
@login_required
def teacher_options():
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    periods = ['08:00-09:00', '09:00-10:00', '10:00-11:00', '11:00-12:00', '12:00-01:00']
    
    schedule = {day: {period: None for period in periods} for day in days}

    if current_user.is_teacher:
        # Teacher's schedule created by admin
        schedule_entries = ScheduleEntry.query.filter_by(teacher_id=current_user.id).all()
        for entry in schedule_entries:
            period_key = f"{entry.time_start}-{entry.time_end}"
            schedule[entry.day_of_week][period_key] = entry.classroom
    else:
        flash('Unauthorized access.', 'danger')
        return redirect(url_for('main.index'))

    # No POST handling needed for schedule creation/update by teachers

    return render_template('teacher_options.html', days=days, periods=periods, schedule=schedule)


@main.route('/toggle_attendance', methods=['POST'])
@login_required
def toggle_attendance():
    day = request.form['day']
    period = request.form['period']
    status = request.form['status']

    # Logic to toggle attendance status
    attendance = AttendanceStatus.query.filter_by(day=day, period=period).first()
    if not attendance:
        attendance = AttendanceStatus(day=day, period=period, status=(status == 'ON'))
        db.session.add(attendance)
    else:
        attendance.status = (status == 'ON')

    db.session.commit()

    flash('Attendance status updated successfully!', 'success')
    return redirect(url_for('main.view_schedule_teacher'))


@main.route('/attendance_control', methods=['GET', 'POST'])
@login_required
def attendance_control():
    if not current_user.is_teacher:
        abort(403)  # Forbidden if the user is not a teacher

    if request.method == 'POST':
        # Extract form data
        day = request.form.get('day')
        period = request.form.get('period')
        status = request.form.get('status') == 'ON'

        # Update or create attendance status
        attendance_status = AttendanceStatus.query.filter_by(day=day, period=period).first()
        if not attendance_status:
            attendance_status = AttendanceStatus(day=day, period=period, status=status)
            db.session.add(attendance_status)
        else:
            attendance_status.status = status
        db.session.commit()

        flash('Attendance control updated!', 'success')
        return redirect(url_for('main.attendance_control'))

    # Default state or fetch state from database
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    periods = ['10:30-11:30', '11:30-12:30', '12:30-1:30', '1:30-2:00', '2:00-3:00', '3:00-4:00', '4:00-5:00', '5:00-6:00']
    attendance = {day: {period: False for period in periods} for day in days}

    # Fetch current attendance status from the database
    for day in days:
        for period in periods:
            status = AttendanceStatus.query.filter_by(day=day, period=period).first()
            if status:
                attendance[day][period] = status.status

    return render_template('attendance_control.html', days=days, periods=periods, attendance=attendance)


@main.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()

    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data)
        user = User(
            email=form.email.data,
            password=hashed_password,
            is_teacher=form.user_type.data == 'teacher',
            is_admin=form.user_type.data == 'admin'
        )
        db.session.add(user)
        db.session.commit()

        if form.user_type.data == 'student':
            student = Student(
                user_id=user.id,
                student_id=form.student_id.data,
                name=form.student_name.data,
                department=form.student_department.data,
                semester=form.student_semester.data,
                batch=form.student_batch.data
            )
            db.session.add(student)

        elif form.user_type.data == 'teacher':
            teacher = Teacher(
                user_id=user.id,
                teacher_id=form.teacher_id.data,
                name=form.teacher_name.data,
                department=form.teacher_department.data
            )
            db.session.add(teacher)

        db.session.commit()
        flash('Account created successfully!', 'success')
        return redirect(url_for('main.login'))

    return render_template('register.html', form=form)


@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        # Debugging statements to verify the current user state
        current_app.logger.debug(f"Already authenticated: User ID = {current_user.id}, Is Teacher = {current_user.is_teacher}, Is Admin = {current_user.is_admin}")
        
        if current_user.is_teacher:
            return redirect(url_for('main.teacher_options'))
        elif current_user.is_admin:
            return redirect(url_for('main.admin_dashboard'))
        else:
            return redirect(url_for('main.student_options'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        
        # Additional debug statements to verify user fetching and password checking
        if user:
            current_app.logger.debug(f"User found: {user.email}, Is Teacher = {user.is_teacher}, Is Admin = {user.is_admin}")
            if check_password_hash(user.password, form.password.data):
                login_user(user, remember=form.remember.data)
                current_app.logger.info(f"User {user.email} logged in successfully.")
                
                if user.is_teacher:
                    return redirect(url_for('main.teacher_options'))
                elif user.is_admin:
                    return redirect(url_for('main.admin_dashboard'))
                else:
                    return redirect(url_for('main.student_options'))
            else:
                current_app.logger.warning(f"Invalid password for user: {user.email}")
        else:
            current_app.logger.warning(f"User not found: {form.email.data}")
        
        flash('Login Unsuccessful. Please check email and password', 'danger')

    current_app.logger.debug(f"Form errors: {form.errors}")
    return render_template('login.html', form=form)


@main.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.login'))


#-> Passed image_paths instead of images to train_model().
@main.route('/train_model', methods=['GET', 'POST'])
@login_required
def train_model_route():
    form = UploadForm()
    training_complete = False

    if form.validate_on_submit():
        uploaded_files = request.files.getlist('photos')  # List of FileStorage objects
        student_id = form.student_id.data

        if not student_id:
            flash('Student ID is required.', 'danger')
            return redirect(url_for('main.train_model_route'))

        image_paths = []
        for file in uploaded_files:
            if file and file.filename:
                filename = secure_filename(file.filename)
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                
                try:
                    file.save(file_path)
                    image_paths.append(file_path)
                except Exception as e:
                    flash(f'Error processing file {filename}: {str(e)}', 'danger')
                    continue

        if image_paths:
            flash('Photos uploaded. Training in progress...', 'info')
            db.session.commit()  # Ensure any previous changes are committed

            # Get model directory dynamically
            model_directory = get_model_directory()

            # Train the model using the CNN approach
            try:
                success = train_model(student_id, image_paths, model_directory)  # Pass model_directory
                if success:
                    flash('Model trained successfully!', 'success')
                    training_complete = True
                    return redirect(url_for('main.test_model'))
                else:
                    flash('Failed to train model. Please try again.', 'danger')
            except Exception as e:
                flash(f'Error during model training: {str(e)}', 'danger')
        else:
            flash('No valid images uploaded.', 'danger')

    return render_template('train_model.html', form=form, training_complete=training_complete)


@main.route('/view_schedule_teacher')
@login_required
def view_schedule_teacher():
    if not current_user.is_teacher:
        abort(403)  # Forbidden if the user is not a teacher

    # Define days and periods
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    periods = ['10:30-11:30', '11:30-12:30', '12:30-1:30', '1:30-2:00', '2:00-3:00', '3:00-4:00', '4:00-5:00', '5:00-6:00']

    # Query schedule entries for the teacher
    schedule_entries = ScheduleEntry.query.filter_by(teacher_id=current_user.teacher_profile.id).all()
    
    # Initialize the schedule dictionary
    schedule = {day: {period: None for period in periods} for day in days}

    for entry in schedule_entries:
        period_key = f"{entry.time_start}-{entry.time_end}"
        if period_key in schedule[entry.day_of_week]:
            schedule[entry.day_of_week][period_key] = entry.classroom

    # Query attendance status for the teacher's schedule
    attendance_entries = AttendanceStatus.query.all()
    attendance_status = {(entry.day, entry.period): entry.status for entry in attendance_entries}

    return render_template(
        'view_schedule_teacher.html', 
        days=days, 
        periods=periods, 
        schedule=schedule,
        attendance_status=attendance_status
    )


logging.basicConfig(level=logging.DEBUG)
@main.route('/view_schedule_student/<student_id>')
@login_required
def view_schedule_student(student_id):
    # Fetch student by student_id
    current_student = Student.query.filter_by(student_id=student_id).first()

    if not current_student:
        abort(404)  # Student not found

    # Check if the user is allowed to view the schedule
    if not (current_user.is_admin or 
            (current_user.is_teacher and current_student.user_id == current_user.id) or
            (current_user.id == current_student.user_id)):
        abort(403)  # Forbidden

    if request.method == 'POST':
        # Handle location check
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')
        if latitude and longitude:
            if not is_within_school(float(latitude), float(longitude)):
                return jsonify({'status': 'error', 'message': 'You are not within the school premises.'})
        return jsonify({'status': 'success'})

    # Fetch the student's schedule entries based on department, batch, and semester
    schedule_entries = ScheduleEntry.query.filter(
        ScheduleEntry.department == current_student.department,
        ScheduleEntry.batch == current_student.batch,
        ScheduleEntry.semester == current_student.semester
    ).all()

    # Initialize schedule dictionary
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    periods = ['10:30-11:30', '11:30-12:30', '12:30-1:30', '1:30-2:00', '2:00-3:00', '3:00-4:00', '4:00-5:00', '5:00-6:00']

    schedule = {day: {period: None for period in periods} for day in days}

    for entry in schedule_entries:
        day = entry.day_of_week
        period = f"{entry.time_start}-{entry.time_end}"
        if day in schedule and period in schedule[day]:
            schedule[day][period] = entry

    # Fetch attendance status for the student's schedule
    attendance_entries = AttendanceStatus.query.all()
    attendance_status = {(entry.day, entry.period): entry.status for entry in attendance_entries}

    return render_template(
        'view_schedule_student.html', 
        schedule=schedule, 
        days=days, 
        periods=periods, 
        student_id=student_id, 
        student_name=current_student.name,
        attendance_status=attendance_status
    )

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@main.route('/admin_view_schedules', methods=['GET', 'POST'])
@login_required
def admin_view_schedules():
    if not current_user.is_admin:
        abort(403)  # Forbidden if the user is not an admin

    # Retrieve distinct filter options
    departments = [dept[0] for dept in db.session.query(Teacher.department).distinct()]
    semesters = [sem[0] for sem in db.session.query(Student.semester).distinct()]
    batches = [batch[0] for batch in db.session.query(Student.batch).distinct()]
    teachers = [teacher.id for teacher in Teacher.query.all()]

    # Get filter values from request arguments
    filters = {
        'department': request.args.get('department'),
        'semester': request.args.get('semester'),
        'batch': request.args.get('batch'),
        'teacher_id': request.args.get('teacher_id')
    }

    # Log filter values
    logger.info(f"Filters applied: {filters}")

    # Build query based on filters
    schedule_entries = ScheduleEntry.query

    # Create table aliases
    StudentAlias = aliased(Student)
    TeacherAlias = aliased(Teacher)

    if filters['department']:
        schedule_entries = schedule_entries.join(TeacherAlias).filter(TeacherAlias.department == filters['department'])
    if filters['semester'] or filters['batch']:
        schedule_entries = schedule_entries.join(StudentAlias).filter(
            and_(
                (StudentAlias.semester == filters['semester']) if filters['semester'] else True,
                (StudentAlias.batch == filters['batch']) if filters['batch'] else True
            )
        )
    if filters['teacher_id']:
        schedule_entries = schedule_entries.filter(ScheduleEntry.teacher_id == filters['teacher_id'])

    # Log the generated SQL query
    query_str = str(schedule_entries.statement.compile(compile_kwargs={"literal_binds": True}))
    logger.info(f"Generated SQL query: {query_str}")

    schedule_entries = schedule_entries.all()

    # Initialize the schedule dictionary
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    periods = ['10:30-11:30', '11:30-12:30', '12:30-1:30', '1:30-2:00', '2:00-3:00', '3:00-4:00', '4:00-5:00', '5:00-6:00']
    schedule = {day: {period: [] for period in periods} for day in days}

    for entry in schedule_entries:
        period_key = f"{entry.time_start}-{entry.time_end}"
        if period_key in schedule[entry.day_of_week]:
            schedule[entry.day_of_week][period_key].append({
                'id': entry.id,
                'classroom': entry.classroom,
                'teacher_id': entry.teacher_id
            })

    return render_template('admin_view_schedules.html', days=days, periods=periods, schedule=schedule,
                           departments=departments, semesters=semesters, batches=batches, teachers=teachers)


@main.route('/edit_schedule/<int:entry_id>', methods=['GET', 'POST'])
@login_required
def edit_schedule(entry_id):
    if not current_user.is_admin:
        abort(403)  # Forbidden if the user is not an admin

    entry = ScheduleEntry.query.get(entry_id)
    if not entry:
        abort(404)  # Schedule entry not found

    departments = Student.query.with_entities(Student.department).distinct().all()
    semesters = [str(i) for i in range(1, 9)]
    batches = [chr(i) for i in range(ord('A'), ord('G') + 1)]
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    periods = ['10:30-11:30', '11:30-12:30', '12:30-1:30', '1:30-2:00', '2:00-3:00', '3:00-4:00', '5:00-6:00']
    teachers = Teacher.query.all()

    if request.method == 'POST':
        day_of_week = request.form['day_of_week']
        time_start = request.form['time_start']
        time_end = request.form['time_end']
        classroom = request.form['classroom']
        teacher_id = request.form['teacher_id']
        department = request.form['department']
        semester = request.form['semester']
        batch = request.form['batch']
        course_name = request.form['course_name']

        # Dynamically insert or find the class in the Class table
        schedule_str = f"{day_of_week} {time_start}-{time_end}"
        existing_class = Class.query.filter_by(name=course_name, teacher_id=teacher_id, schedule=schedule_str).first()

        if not existing_class:
            new_class = Class(name=course_name, teacher_id=teacher_id, schedule=schedule_str)
            db.session.add(new_class)
            db.session.commit()
            class_id = new_class.id
        else:
            class_id = existing_class.id

        # Update the schedule entry with the new information
        entry.day_of_week = day_of_week
        entry.time_start = time_start
        entry.time_end = time_end
        entry.classroom = classroom
        entry.teacher_id = teacher_id
        entry.department = department
        entry.semester = semester
        entry.batch = batch
        entry.course_name = course_name

        db.session.commit()
        flash('Schedule updated successfully!', 'success')
        return redirect(url_for('main.admin_view_schedules'))

    return render_template('edit_schedule.html',
                           entry=entry,
                           departments=departments, 
                           semesters=semesters, 
                           batches=batches, 
                           days=days, 
                           periods=periods, 
                           teachers=teachers)


@main.route('/delete_schedule/<int:entry_id>')
@login_required
def delete_schedule(entry_id):
    if not current_user.is_admin:
        abort(403)  # Forbidden if the user is not an admin

    entry = ScheduleEntry.query.get(entry_id)
    if not entry:
        abort(404)  # Schedule entry not found

    db.session.delete(entry)
    db.session.commit()
    flash('Schedule deleted successfully!', 'success')
    return redirect(url_for('main.admin_view_schedules'))


@main.route('/recognize_face', methods=['POST'])
def recognize_face_route():
    data = request.get_json()
    image_data = data.get('image')
    student_id = data.get('student_id')
       
    if not image_data or not student_id:
        return jsonify({'error': 'Invalid request'}), 400

    model_directory = get_model_directory()  # Get the model directory

    try:
        # Recognize face
        recognized_id = recognize_face(image_data, student_id, model_directory)
        if recognized_id:
            return jsonify({'student_id': recognized_id})
        else:
            return jsonify({'error': 'No student recognized'})
    except Exception as e:
        logging.error(f"Error during face recognition: {str(e)}", exc_info=True)
        return jsonify({'error': 'An error occurred. Check the log for details.'}), 500


@main.route('/test_model')
@login_required
def test_model():
    student_profile = current_user.student_profile

    if student_profile:
        student_id = student_profile.student_id
        return render_template('test_model.html', student_id=student_id)
    else:
        flash('Student profile not found.', 'danger')
        return redirect(url_for('main.train_model_route'))
    

@main.route('/process_attendance', methods=['POST'])
@login_required
def process_attendance():
    logging.debug(f"Current user: {current_user}")

    try:
        data = request.json
        image_data = data.get('image_data')
        student_id = data.get('student_id')
        course_name = data.get('course_name')  # Use course_name instead of classroom

        logging.debug(f"Received image data length: {len(image_data) if image_data else 'None'}")
        logging.debug(f"Received student ID: {student_id}")
        logging.debug(f"Received course name: {course_name}")

        if image_data and student_id and course_name:
            model_directory = get_model_directory()
            recognized_id = recognize_face(image_data, student_id, model_directory)

            if recognized_id:
                logging.debug(f"Face recognized. Recording attendance for student ID: {student_id}")

                # Fetch student record using student_id
                student = Student.query.filter_by(student_id=student_id).first()

                if student:
                    # Fetch the corresponding Class instance using course_name
                    class_instance = Class.query.filter_by(name=course_name).first()

                    if class_instance:
                        # Create attendance record
                        attendance_record = AttendanceRecord(
                            student_id=student.id,  # Use student.id for the record
                            class_id=class_instance.id,  # Use the ID of the class instance
                            timestamp=datetime.utcnow(),
                            present=True
                        )
                        db.session.add(attendance_record)
                        db.session.commit()

                        # Fetch the student name for response
                        student_name = student.name
                        return jsonify({'success': True, 'student_name': student_name}), 200
                    else:
                        return jsonify({'success': False, 'error': 'Class not found.'}), 400
                else:
                    return jsonify({'success': False, 'error': 'Student not found.'}), 400
            else:
                return jsonify({'success': False, 'error': 'Face not recognized.'}), 400
        else:
            return jsonify({'success': False, 'error': 'No image data, student ID, or course name received.'}), 400
    except Exception as e:
        logging.error(f"Error processing attendance: {e}")
        return jsonify({'success': False, 'error': 'An error occurred while processing attendance.'}), 500


@main.route('/attendance') #for student
@login_required
def attendance():
    # Fetch the student based on the current user
    student = Student.query.filter_by(user_id=current_user.id).first()

    if student:
        # Fetch attendance records for the student, including related Class data
        attendance_records = (
            AttendanceRecord.query
            .filter_by(student_id=student.id)
            .join(Class)  # Join the Class model
            .all()
        )
    else:
        attendance_records = []

    # Check if there are no attendance records
    if not attendance_records:
        flash('No attendance records found. Please take attendance first.', 'info')
        return redirect(url_for('main.student_options'))

    course_attendance = {}

    # Create a dictionary to store course names from the Class table
    classes = Class.query.all()
    logging.debug(f"Fetched Classes: {classes}")
    for cls in classes:
        logging.debug(f"Class ID: {cls.id}, Name: {cls.name}")

    schedule_entry_map = {cls.id: cls.name for cls in classes}

    # Debugging output to verify the mapping
    logging.debug("Class Entry Map: %s", schedule_entry_map)

    for record in attendance_records:
        # Fetch the course name from class entry map using the class_id
        course_name = schedule_entry_map.get(record.class_id, 'Unknown Course')
        logging.debug(f"Record ID: {record.id}, Class ID: {record.class_id}, Course Name: {course_name}")

        if course_name not in course_attendance:
            course_attendance[course_name] = {
                'total_classes': 0,
                'attended_classes': 0
            }
        course_attendance[course_name]['total_classes'] += 1
        if record.present:
            course_attendance[course_name]['attended_classes'] += 1

    # Print out the course attendance for debugging
    print("Course Attendance Data:", course_attendance)

    # Calculate attendance percentage for each course
    for course, data in course_attendance.items():
        total_classes = data['total_classes']
        attended_classes = data['attended_classes']
        if total_classes > 0:
            data['attendance_percentage'] = int((attended_classes / total_classes) * 100)
        else:
            data['attendance_percentage'] = 0

    return render_template('attendance.html', attendance_records=attendance_records, course_attendance=course_attendance)


@main.route('/admin/view_all_student_attendance', methods=['GET'])
@login_required
def view_all_student_attendance():
    if not current_user.is_admin:
        return "Access denied", 403

    semester = request.args.get('semester')
    batch = request.args.get('batch')
    department = request.args.get('department')
    student_id = request.args.get('student_id')

    # Filter students based on provided criteria
    query = Student.query

    if semester:
        query = query.filter_by(semester=semester)
    if batch:
        query = query.filter_by(batch=batch)
    if department:
        query = query.filter_by(department=department)
    if student_id:
        query = query.filter_by(student_id=student_id)

    students = query.all()
    student_ids = [student.id for student in students]
    attendance_records = AttendanceRecord.query.filter(AttendanceRecord.student_id.in_(student_ids)).all()

    student_data = []
    for student in students:
        records = [rec for rec in attendance_records if rec.student_id == student.id]
        total_classes = len(records)
        attended_classes = sum(rec.present for rec in records)
        attendance_percentage = int((attended_classes / total_classes) * 100) if total_classes > 0 else 0

        student_data.append({
            'student_id': student.student_id,
            'student_name': student.name,
            'total_classes': total_classes,
            'attended_classes': attended_classes,
            'attendance_percentage': attendance_percentage
        })

    # Get unique semesters, batches, and departments for filtering
    semesters = Student.query.with_entities(Student.semester).distinct().all()
    batches = Student.query.with_entities(Student.batch).distinct().all()
    departments = Student.query.with_entities(Student.department).distinct().all()

    return render_template('admin_all_student_attendance.html',
                           attendance_records=student_data,
                           semesters=[sem[0] for sem in semesters],
                           batches=[bat[0] for bat in batches],
                           departments=[dept[0] for dept in departments])


@main.route('/view_student_attendance', methods=['GET']) #for teacher
@login_required
def view_student_attendance():
    # Fetch the teacher profile based on the current user
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    if not teacher:
        return "Teacher profile not found", 404

    # Fetch filter parameters from the request
    semester = request.args.get('semester')
    batch = request.args.get('batch')
    department = request.args.get('department')
    student_id = request.args.get('student_id')

    # Fetch all classes for the teacher
    classes = Class.query.filter_by(teacher_id=teacher.id).all()

    # Initialize the list to store attendance records
    filtered_attendance_records = []

    # Iterate over each class
    for cls in classes:
        # Fetch attendance records for the class, applying filters
        query = AttendanceRecord.query.join(Student).filter(AttendanceRecord.class_id == cls.id)

        if semester:
            query = query.filter(Student.semester == semester)
        if batch:
            query = query.filter(Student.batch == batch)
        if department:
            query = query.filter(Student.department == department)
        if student_id:
            query = query.filter(Student.id == student_id)

        records = query.all()

        for record in records:
            student = record.student
            # Find or create the attendance summary for this student in this class
            attendance_summary = next((item for item in filtered_attendance_records 
                                       if item['student_id'] == student.id and item['class_name'] == cls.name), None)
            if attendance_summary is None:
                attendance_summary = {
                    'student_id': student.id,
                    'student_name': student.name,
                    'class_name': cls.name,
                    'total_classes': 0,
                    'attended_classes': 0,
                }
                filtered_attendance_records.append(attendance_summary)

            # Update attendance summary
            attendance_summary['total_classes'] += 1
            if record.present:
                attendance_summary['attended_classes'] += 1

    # Calculate attendance percentage for each record
    for summary in filtered_attendance_records:
        summary['attendance_percentage'] = (summary['attended_classes'] / summary['total_classes']) * 100 if summary['total_classes'] > 0 else 0

    # Fetch unique semesters, batches, and departments for filters
    semesters = Student.query.with_entities(Student.semester).distinct().all()
    batches = Student.query.with_entities(Student.batch).distinct().all()
    departments = Student.query.with_entities(Student.department).distinct().all()

    return render_template(
        'view_student_attendance.html', 
        attendance_records=filtered_attendance_records, 
        semesters=[s.semester for s in semesters],
        batches=[b.batch for b in batches],
        departments=[d.department for d in departments]
    )

@main.route('/create_schedule', methods=['GET', 'POST'])
@login_required
def create_schedule():
    if not current_user.is_admin:
        abort(403)

    departments = Student.query.with_entities(Student.department).distinct().all()
    semesters = [str(i) for i in range(1, 9)]
    batches = [chr(i) for i in range(ord('A'), ord('G') + 1)]
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    periods = ['10:30-11:30', '11:30-12:30', '12:30-1:30', '1:30-2:00', '2:00-3:00', '3:00-4:00', '5:00-6:00']
    teachers = Teacher.query.all()

    if request.method == 'POST':
        day_of_week = request.form['day_of_week']
        time_start = request.form['time_start']
        time_end = request.form['time_end']
        classroom = request.form['classroom']
        teacher_id = request.form['teacher_id']
        department = request.form['department']
        semester = request.form['semester']
        batch = request.form['batch']
        course_name = request.form['course_name']  # New field

        # Dynamically insert or find the class in the Class table
        schedule_str = f"{day_of_week} {time_start}-{time_end}"
        existing_class = Class.query.filter_by(name=course_name, teacher_id=teacher_id, schedule=schedule_str).first()

        if not existing_class:
            new_class = Class(name=course_name, teacher_id=teacher_id, schedule=schedule_str)
            db.session.add(new_class)
            db.session.commit()
            class_id = new_class.id
        else:
            class_id = existing_class.id

        # Handle teacher schedule entry
        if teacher_id:
            existing_entry = ScheduleEntry.query.filter_by(
                teacher_id=teacher_id,
                day_of_week=day_of_week,
                time_start=time_start,
                time_end=time_end
            ).first()
            if existing_entry:
                existing_entry.classroom = classroom
                existing_entry.course_name = course_name  # Set course name
                existing_entry.department = None
                existing_entry.batch = None
                existing_entry.semester = None
            else:
                new_entry = ScheduleEntry(
                    teacher_id=teacher_id,
                    day_of_week=day_of_week,
                    time_start=time_start,
                    time_end=time_end,
                    classroom=classroom,
                    course_name=course_name  # Set course name
                )
                db.session.add(new_entry)
            db.session.commit()
            flash('Teacher schedule updated successfully!', 'success')
            return redirect(url_for('main.create_schedule'))

        # Handle student schedule entry
        if department or semester or batch:
            students = Student.query.filter_by(department=department, semester=semester, batch=batch).all()
            print(f"Students found: {[student.id for student in students]}")
            for student in students:
                existing_entry = ScheduleEntry.query.filter_by(
                    student_id=student.id,
                    day_of_week=day_of_week,
                    time_start=time_start,
                    time_end=time_end
                ).first()
                if existing_entry:
                    existing_entry.classroom = classroom
                    existing_entry.teacher_id = teacher_id
                    existing_entry.course_name = course_name  # Set course name
                    existing_entry.department = department
                    existing_entry.batch = batch
                    existing_entry.semester = semester
                else:
                    new_entry = ScheduleEntry(
                        student_id=student.id,
                        day_of_week=day_of_week,
                        time_start=time_start,
                        time_end=time_end,
                        classroom=classroom,
                        teacher_id=teacher_id,
                        course_name=course_name,  # Set course name
                        department=department,
                        batch=batch,
                        semester=semester
                    )
                    db.session.add(new_entry)
            db.session.commit()
            flash('Student schedule updated successfully!', 'success')
            return redirect(url_for('main.create_schedule'))

    return render_template('create_schedule.html', 
                           departments=departments, 
                           semesters=semesters, 
                           batches=batches, 
                           days=days, 
                           periods=periods, 
                           teachers=teachers)

@main.route('/take_attendance', methods=['GET'])
@login_required
def take_attendance():
    day = request.args.get('day')
    period = request.args.get('period')
    student_id = request.args.get('student_id')

    # Check if the current user is a student or a teacher
    if not current_user.is_teacher and not current_user.student_profile:
        abort(403)

    # Get student_id from the current user if not provided
    if not student_id:
        student_profile = current_user.student_profile
        student_id = student_profile.student_id if student_profile else None

    if not student_id:
        flash('Student ID not found.', 'error')
        return render_template('take_attendance.html', day=day, period=period, student_id=None, classroom=None)

    # Retrieve student profile to get department, batch, and semester
    student_profile = Student.query.filter_by(student_id=student_id).first()
    if not student_profile:
        flash('Student profile not found.', 'error')
        return render_template('take_attendance.html', day=day, period=period, student_id=student_id, classroom=None)
    
    department = student_profile.department
    batch = student_profile.batch
    semester = student_profile.semester

    # Debugging: Log the parameters
    logging.debug(f"Searching for schedule entry with Day: {day}, Period: {period}, Department: {department}, Batch: {batch}, Semester: {semester}")

    # Check if period is provided
    if not period:
        logging.error("Period is not provided.")
        flash('Period is required.', 'error')
        return render_template('take_attendance.html', day=day, period=period, student_id=student_id, classroom=None)

    # Split period into start and end times
    try:
        period_start, period_end = period.split('-')
        period_start = period_start.strip()
        period_end = period_end.strip()
    except ValueError:
        logging.error(f"Error splitting period: {period}")
        flash('Invalid period format.', 'error')
        return render_template('take_attendance.html', day=day, period=period, student_id=student_id, classroom=None)

    # Find the course name using day, period, and student profile attributes
    schedule_entries = ScheduleEntry.query.filter_by(
        day_of_week=day,
        time_start=period_start,
        time_end=period_end,
        department=department,
        batch=batch,
        semester=semester
    ).all()

    logging.debug(f"Schedule Entries Found: {len(schedule_entries)}")
    
    course_name = None
    for entry in schedule_entries:
        logging.debug(f"Checking Entry: Course Name: {entry.course_name}")
        # Assuming that if any entry matches, it should be used
        if entry.course_name:
            course_name = entry.course_name
            break

    if not course_name:
        flash('No schedule entry found for the given details.', 'error')
        return render_template('take_attendance.html', day=day, period=period, student_id=student_id, classroom=None)
    
    return render_template('take_attendance.html', day=day, period=period, student_id=student_id, classroom=course_name)


@main.route('/update_location', methods=['POST'])
@login_required
def update_location():
    latitude = request.form['latitude']
    longitude = request.form['longitude']

    student = Student.query.filter_by(user_id=current_user.id).first()
    if student:
        student.latitude = float(latitude)
        student.longitude = float(longitude)
        db.session.commit()

    flash('Location updated successfully!', 'success')
    return redirect(url_for('main.view_schedule_student'))


@main.route('/check_student_location', methods=['POST'])
def check_student_location():
    try:
        latitude = float(request.form.get('latitude'))
        longitude = float(request.form.get('longitude'))

        current_app.logger.debug(f"Received data - Latitude: {latitude}, Longitude: {longitude}")

        if is_within_school(latitude, longitude):
            return jsonify({'status': 'success'})
        else:
            return jsonify({'status': 'error', 'message': 'You are not within the allowed area to take attendance.'})

    except Exception as e:
        current_app.logger.error(f"Exception occurred: {e}")
        return jsonify({'status': 'error', 'message': 'An error occurred.'})


@main.route('/view_filtered_student_attendance', methods=['GET'])
@login_required
def view_filtered_student_attendance():
    semester = request.args.get('semester')
    batch = request.args.get('batch')
    department = request.args.get('department')
    student_id = request.args.get('student_id')

    # Fetch all students for the current teacher
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    if not teacher:
        return "Teacher profile not found", 404

    classes = Class.query.filter_by(teacher_id=teacher.id).all()
    class_ids = [cls.id for cls in classes]

    # Filter students based on class assignments and other criteria
    query = Student.query.filter(Student.id.in_(
        AttendanceRecord.query.filter(AttendanceRecord.class_id.in_(class_ids)).with_entities(AttendanceRecord.student_id)
    ))

    if semester:
        query = query.filter_by(semester=semester)
    if batch:
        query = query.filter_by(batch=batch)
    if department:
        query = query.filter_by(department=department)
    if student_id:
        query = query.filter_by(student_id=student_id)
    
    students = query.all()

    # Fetch attendance records for these students
    student_ids = [student.id for student in students]
    attendance_records = AttendanceRecord.query.filter(AttendanceRecord.student_id.in_(student_ids)).all()

    # Create a dictionary to map class IDs to class names
    class_dict = {}
    for record in attendance_records:
        class_ = Class.query.get(record.class_id)
        if class_:
            class_dict[class_.id] = class_.name

    # Prepare data for the template
    student_data = []
    for student in students:
        records = [rec for rec in attendance_records if rec.student_id == student.id]
        total_classes = len(records)
        attended_classes = sum(rec.present for rec in records)
        attendance_percentage = int((attended_classes / total_classes) * 100) if total_classes > 0 else 0

        # Fetch class names for each student
        classes = set()
        for rec in records:
            class_name = class_dict.get(rec.class_id, 'Unknown')
            classes.add(class_name)
        
        student_data.append({
            'student_id': student.student_id,
            'student_name': student.name,
            'class_name': ', '.join(classes),  # Join class names if multiple
            'total_classes': total_classes,
            'attended_classes': attended_classes,
            'attendance_percentage': attendance_percentage
        })

    # Get unique semesters, batches, and departments for filtering
    semesters = Student.query.with_entities(Student.semester).distinct().all()
    batches = Student.query.with_entities(Student.batch).distinct().all()
    departments = Student.query.with_entities(Student.department).distinct().all()

    return render_template('view_student_attendance.html', 
                           attendance_records=student_data,
                           semesters=[sem[0] for sem in semesters],
                           batches=[bat[0] for bat in batches],
                           departments=[dept[0] for dept in departments])


@main.route('/student_attendance/<int:student_id>', methods=['GET'])
@login_required
def student_attendance(student_id):
    # Fetch attendance details for the student
    student = Student.query.get_or_404(student_id)
    # Assuming you have a method to get detailed attendance records
    records = get_attendance_details(student)
    return render_template('student_attendance.html', student=student, records=records)


@main.route('/attendance_records', methods=['GET'])
@login_required
def attendance_records():
    students = Student.query.all()
    # Calculate attendance percentage for each student
    # You should have a method to compute this
    student_data = [{'id': student.id, 'attendance_percentage': calculate_attendance_percentage(student)} for student in students]
    return render_template('attendance_records.html', students=student_data)